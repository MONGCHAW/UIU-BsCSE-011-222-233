
#include<stdio.h>

void main(){
    

//Initializing values

    char c;                              /*Unintialized values*/

//Inputting the Character

    printf("Enter a character: ");                
    scanf("%c", &c);

//Printing the answers

    printf("ASCII value of %c = %d", c, c);


}