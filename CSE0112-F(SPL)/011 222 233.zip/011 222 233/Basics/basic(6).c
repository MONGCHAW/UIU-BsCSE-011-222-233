#include <stdio.h>

void main()
{
//Variable Initialization
  float meter, feet;                          //Uninitialized variables 

// Inputing Numbers
  printf("Enter First numbers: ");
  scanf("%d",&feet);

//Arithmatic Oparations
  meter = feet / 3.2808399;

//Printing the Answers
  printf("meter: %f",meter);

}
