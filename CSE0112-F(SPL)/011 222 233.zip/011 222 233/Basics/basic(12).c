#include<stdio.h>

void main(){
    

//Initializing values

   int width, area;                          /*Unintialized values*/


//Inputting the 

   printf("Enter the Length of Side :");
   scanf("%d", &width);

//Arithmatic Oparation

   area = width * width;

//Printing the answers

   printf("\nArea of Square : %d", area);


}