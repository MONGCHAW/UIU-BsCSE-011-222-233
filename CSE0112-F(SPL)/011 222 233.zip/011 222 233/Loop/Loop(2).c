#include <stdio.h>
void main()
{
    int i;
    for(  i=0; i<=255; i++)
    {
        printf("ASCII value of %c = %d\n", i, i);
    }
}