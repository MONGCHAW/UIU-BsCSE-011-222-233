#include <stdio.h>
void main()
{
    char ch;
    printf("Alphabets from A to Z are: \n");
    for(ch='A'; ch<='Z'; ch++)
    {
        printf("%c  ", ch);
    }
}