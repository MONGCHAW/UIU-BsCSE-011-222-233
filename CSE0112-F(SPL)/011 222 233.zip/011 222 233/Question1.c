#include <stdio.h>

void main() {

//Initilizing Value
    int n1, n2, n3;

//Inputting Numbers

    printf("Enter the numbers:\n");
    scanf("%d %d %d", &n1, &n2 , &n3);

//Printing The Numbers

    printf("First Number- %d, Last Number-%d", n1, n3);

}